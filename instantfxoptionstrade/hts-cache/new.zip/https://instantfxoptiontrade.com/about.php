<!DOCTYPE html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
     <title>Instantfxoptiontrade</title>
     <link rel="stylesheet" href="data/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css" type="text/css" media="all"/>
     <link rel="stylesheet" href="data/design/cryptonode/css/bootstrap.css" type="text/css" media="all"/>
     <link rel="stylesheet" href="data/design/cryptonode/css/core.css" type="text/css" media="all"/>
     <link rel="stylesheet" href="data/design/cryptonode/css/components.html" type="text/css" media="all"/>
     <link rel="stylesheet" href="data/design/cryptonode/css/button.css" type="text/css" media="all"/>
     <link rel="icon" href="data/design/cryptonode/images/favicon.png" type="image/x-icon"/>
     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans%3A400italic%2C400%2C500%2C600%2C700%2C300&amp;subset=latin%2Clatin-ext&amp;ver=4.9.14" type="text/css" media="all"/>
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="shortcut icon" href="images/bitcoin31.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">.btn,.button,.cart_totals th,.contact-number,.featured-title,.filter-dark button,.filter:not(.filter-dark) button,.font1,.h5,.onsale,.orderform .quantity-field,.page-header .page-title,.product-top-meta,.quantity .quantity-field,.rev_slider,.search-notice-label,.site-footer .widget_recent_entries a,.title.h5,:not(.widget)>.download,h1,h2,h3,h4,h5,h6,table.table>tbody th,table.table>tfoot th,table.table>thead th{font-family:"Nunito Sans"}body{font-family:"Nunito Sans"}.menu-button{font-family:"Nunito Sans"}body{font-size:18px}h1{font-size:31px}h2{font-size:45px}h3{font-size:32px}h4{font-size:22px}h5{font-size:20px}.site-footer{font-size:18px}.copyright-footer{font-size:16px}@media (min-width:1400px){.container{width:1370px}}html{--anps-text-color:#fff;--anps-page-bg:#0a1992;--anps-secondary:#ffece6;--anps-primary:#fcc754;--anps-headings:#fcc754;--anps-menu-font-size:16px;--anps-submenu-font-size:15px;--anps-top-bar-font-size:13px;--anps-breadcrumbs-color:#999cab;--anps-breadcrumbs-border-color:#e7e7e7;--anps-breadcrumbs-bg-color:#fff;--anps-main-space-top:90px;--anps-main-space-bottom:90px;--anps-top-bar-color:#fdfdfd;--anps-top-bar-bg-color:#000537;--anps-top-bar-height:42px;--anps-menu-mobile-icons:#fff;--anps-submenu-bg-color:#fff;--anps-submenu-color:#8c8c8c;--anps-submenu-color--active:#000;--anps-submenu-color--hover:#000;--anps-page-title:#fff;--anps-page-header-bg:linear-gradient(90deg,#182373,#4f2fac);--anps-page-header-height:280px;--anps-page-header-lg-height:370px;--anps-menu-color:#fdfdfd;--anps-menu-color--hover:#fdc962;--anps-menu-color--active:#fff;--anps-header-search-text-color:#000;--anps-header-search-background-color:#888;--anps-hmain-bg:#171d2f;--anps-hbar-height:110px;--anps-hbar-height--sticky:90px;--anps-hbar-m-height:74px;--anps-hbar-m-height--sticky:60px;--anps-sticky-bg:#000537;--anps-sticky-color:#fff;--anps-sticky-color--hover:#fff;--anps-sticky-color--active:#fff;--anps-crypto-bar-bg:#000;--anps-footer-heading-color:#fcc754;--anps-menu-spacing:15px;--anps-whitelist-token-overlay-bg-color:rgba(255,255,255,.8)}body{color:#fdfdfd}.anps-member-social__link,.bg-primary,.demo_store_wrapper,.featured-has-icon .featured-title:before,.mini-cart-content .buttons a,.nav-links>:not(.dots).current,.nav-links>:not(.dots):focus,.nav-links>:not(.dots):hover,.onsale,.owl-nav button,.pika-next,.pika-prev,.sidebar .download a,.site-footer .widget_price_filter .price_slider_amount button.button,.site-footer .widget_price_filter .ui-slider .ui-slider-range,.site-footer .widget_shopping_cart_content .buttons a,.social a,.widget_calendar a,.widget_calendar caption,.woocommerce-product-gallery__trigger,article.post.sticky .post-content:before,article.post.sticky .post-meta:before,article.post.sticky .post-title:before,aside .widget_price_filter .price_slider_amount button.button,aside .widget_price_filter .ui-slider .ui-slider-range,aside .widget_shopping_cart_content .buttons a,mark,table.table>tbody tr.bg-primary,table.table>tbody.bg-primary tr,table.table>tfoot tr.bg-primary,table.table>tfoot.bg-primary tr,table.table>thead tr.bg-primary,table.table>thead.bg-primary tr,ul.page-numbers>li>.current,ul.page-numbers>li>:focus,ul.page-numbers>li>:hover{background-color:#fcc754}::-moz-selection{background-color:#fcc754}::selection{background-color:#fcc754}.anps-info-icons-wrap,.anps-info-it-wrap,.breadcrumb a:focus,.breadcrumb a:hover,.comment-date i,.contact-info i,.copyright-footer a,.counter-wrap .title,.featured-has-icon.simple-style .featured-title i,.filter-dark button.selected,.filter:not(.filter-dark) button.selected,.filter:not(.filter-dark) button:focus,.heading-left span:before,.heading-middle span:before,.icon-media,.info-table-icon,.jobtitle,.list li:before,.megamenu-title,.mini-cart-content .total .amount,.panel-heading a.collapsed:focus,.panel-heading a.collapsed:hover,.post-info td a:focus,.post-info td a:hover,.post-meta i,.product_list_widget .amount,.product_list_widget ins,.product_meta .posted_in a:focus,.product_meta .posted_in a:hover,.projects-item .project-title,.site-footer .download a:focus,.site-footer .download a:hover,.site-footer .social.social-minimal a:focus,.site-footer .social.social-minimal a:hover,.site-footer .widget_price_filter .price_slider_amount .from,.site-footer .widget_price_filter .price_slider_amount .to,.site-footer .widget_recent_entries .post-date:before,.social.social-border a:focus,.social.social-border a:hover,.social.social-transparent-border a:focus,.social.social-transparent-border a:hover,.star-rating,.stars,.stars a:focus,.stars a:hover,.testimonials-style-3 .testimonials-wrap .content p::before,.testimonials-style-3 .testimonials-wrap .name-user,.vc_gitem_row .vc_gitem-col.anps-grid .vc_gitem-post-data-source-post_date>div:before,.vc_gitem_row .vc_gitem-col.anps-grid-mansonry .vc_gitem-post-data-source-post_date>div:before,.widget_calendar #today,.widget_rss ul .rsswidget,.wpcf7-form-control-wrap[class*=date-]:after,[itemprop=datePublished]:before,a,a.featured-lightbox-link,aside .widget_price_filter .price_slider_amount .from,aside .widget_price_filter .price_slider_amount .to,aside.sidebar .widget_nav_menu .current-menu-item>a,b,header a:focus,nav.site-navigation ul li a:active,nav.site-navigation ul li a:focus,nav.site-navigation ul li a:hover,ol.list,ul.testimonial-wrap .rating,ul.testimonial-wrap .user-data .name-user{color:#fcc754}.blockquote-style-1 p,.blockquote-style-2 p,.featured-content,.gallery-fs .owl-item a.selected:after,.gallery-fs .owl-item a:focus:after,.gallery-fs .owl-item a:hover:after,.post-minimal-wrap,blockquote:not([class]) p{border-color:#fcc754}.copyright-footer a:focus,.copyright-footer a:hover,a:focus,a:hover{color:#fff}.form-group input:not([type=submit]):focus,.form-group input:not([type=submit]):hover,.form-group textarea:focus,.form-group textarea:hover,.input-text:focus,.input-text:hover,.wpcf7 input:not([type=submit]):focus,.wpcf7 input:not([type=submit]):hover,.wpcf7 textarea:focus,.wpcf7 textarea:hover,input{outline-color:#1d2128}h1,h2,h3,h4,h5{color:#fcc754}.site-footer{background-color:#000537}.site-footer{color:#cacbd1}.copyright-footer{background-color:#010745;color:#fff}.anps-btn--style-0{color:#020e68;border-radius:10px;background-image:linear-gradient(to right,#fdcb68,orange);box-shadow:0 10px 25px 0 #061487}.anps-btn--style-8{color:#020e68;background-image:linear-gradient(to right,#fdcb68,orange);border-color:#ffb531;border-radius:30px;border-width:2px;border:0;padding:10px 40px}.anps-btn--style-0:focus,.anps-btn--style-0:hover{color:#020e68;border-radius:10px;box-shadow:0 10px 35px 0 #020e68}.anps-btn--style-8:focus,.anps-btn--style-8:hover{color:#000;background-image:linear-gradient(to right,orange,#fdcb68);border-color:#fdcb68;border-radius:30px;border-width:2px}*,::before,:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;margin:0}:active,:focus,:hover{outline:0;outline-offset:0}*{-webkit-touch-callout:text!important;-webkit-user-select:text!important;-khtml-user-select:text!important;-moz-user-select:text!important;-ms-user-select:text!important;user-select:text!important}</style>
<link rel="stylesheet" href="data/plugins/js_composer/assets/css/js_composer.min.css" type="text/css" media="all"/><script type="text/javascript" src="data/jquery/jquery.js"></script><script type="text/javascript" src="data/jquery/jquery-migrate.min.js"></script>
<style type="text/css" data-type="vc_shortcodes-custom-css">@keyframes animatednumbers{0{background-position:100% 0}25%{background-position:90% 100%}50%{background-position:100% 0}75%{background-position:90% 100%}}@keyframes graph{from{background-position:-2000px 100%,0 0}to{background-position:0 100%,0 0}}@-webkit-keyframes graph{from{background-position:-2000px 100%,0 0}to{background-position:0 100%,0 0}}@keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}@-moz-keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}@-webkit-keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}@-o-keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}.accb1{min-width:130px;width:11.6%;height:100px;background:#000537;border-radius:10px 10px 10px 10px;-moz-border-radius:10px 10px 10px 10px;-webkit-border-radius:10px 10px 10px 10px;float:left;text-align:center;color:#fff;font-size:14px;margin:0 5px 20px 5px;-webkit-transition:.3s ease-in-out;-moz-transition:.3s ease-in-out;-ms-transition:.3s ease-in-out;-o-transition:.3s ease-in-out;transition:.3s ease-in-out;-webkit-box-shadow:0 7px 15px -9px rgba(0,0,0,.3);-moz-box-shadow:0 7px 15px -9px rgba(0,0,0,.3);box-shadow:0 7px 15px -9px rgba(0,0,0,.3)}.accb1:hover{background:#ffa501;color:#fff}.accb1 img{display:block;padding:15px 0 5px 0;width:45px}</style>
</head><body class="home page-template-default page page-id-6 stickyheader header-spacing-off wpb-js-composer js-comp-ver-5.4.5 vc_responsive"><div class="site"><div class="site-wrap"><div class="top-bar top-bar--desktop top-bar--mobile"><div class="container"><div class="top-bar-row"><div class="top-bar-left"><div id="anpstext-2" class="widget widget_anpstext"><ul class="contact-info"><li class="contact-info-item" style="list-style: none"><i class="fa fa-map-marker" style="color: #ffad21; margin-right: 10px"></i><span class="important" style="color: #fdfdfd;">10 111 Mallinson Road London, SW11 1BL, ENGLAND, United Kingdom</span></li></ul></div></div><div class="top-bar-right"><div id="anpstext-3" class="widget widget_anpstext"><ul class="contact-info"><li class="contact-info-item" style="list-style: none"><i class="fa fa-envelope-o" style="color: #ffad21; margin-right: 5px"></i><span class="important" style="color: #fdfdfd;"> info@instantfxoptiontrade.com </span></li></ul></div></div></div></div></div><header class="anps-header anps-header--top anps-header--shadow anps-header--transparent anps-header--right"><div class="anps-header__wrap"><div class="anps-header__bar" data-height="90px" data-m-height="74px"><div class="container"><div class="anps-header__content"><div class="anps-logo"><a href="index.html"><span class="anps-logo__main"><img src="data/design/cryptonode/images/logo.png" alt="CryptoNode" class="logo-img" style="width: 250px"/></span><span class="anps-logo__sticky"><img src="data/design/cryptonode/images/logo.png" alt="CryptoNode" class="logo-img" style="width: 200px"/></span><span class="anps-logo__mobile"><img src="data/design/cryptonode/images/logo.png" alt="CryptoNode" class="logo-img" style="width: 250px"/></span></a></div><nav class="anps-main-nav"><ul id="anps-main-menu" class="anps-main-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="index.html">Home</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="about.php">About us</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="faq.php">FAQ</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="rules.php">Rules</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="contact.php">Contact us</a></li><li class="menu-button"><a href="signup.html" target="_self" class="anps-btn anps-btn--menu anps-btn--style-8 anps-btn--border"> Members login</a></li><li class="menu-button"><a href="register.html" target="_self" class="anps-btn anps-btn--menu anps-btn--style-8 anps-btn--border"> Open an account</a></li></ul></nav><button class="anps-menu-toggle"><i class="fa fa-bars"></i></button></div></div></div></div></header><nav class="anps-mobile-menu"><ul id="main-menu" class="main-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="index.html">Home</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="about.php">About us</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="faq.php">FAQ</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="rules.php">Rules</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="contact.php">Contact us</a></li><li class="menu-button"><a href="signup.php" target="_self" class="anps-btn anps-btn--menu anps-btn--style-8 anps-btn--border"> Members login</a></li><li class="menu-button"><a href="register.php" target="_self" class="anps-btn anps-btn--menu anps-btn--style-8 anps-btn--border"> Open an account</a></li></ul></nav><div style="height: 220px; margin-bottom: 0px;background: url(data/design/cryptonode/images/header.jpg) bottom right no-repeat #0a1992;"></div><main class="site-main"><div class="container content-container"><div class="row"><div class="col-md-12"><div class="page-content-wrap">
<div class="vc_row wpb_row vc_row-fluid vc_column-gap-30 vc_row-o-content-middle vc_row-flex">
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1531488202137">
<figure class="wpb_wrapper vc_figure">
<div class="vc_single_image-wrapper vc_box_border_grey">

<iframe width="560" height="315" src="https://www.youtube.com/embed/GmOzih6I1zs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
</figure>
</div>
</div>
</div>
</div>


<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<h2 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||20;font-size:|||30;line-height:|||1.3;" class="anps-heading__text">About Instantfxoptiontrade</span>
</h2>
<div class="wpb_text_column wpb_content_element">
<div class="wpb_wrapper">
<p style="text-align: justify;">
Instantfxoptiontrade LTD is United Kingdom registered company, (Company Number: 12057659, 10 111 Mallinson Road London, SW11 1BL, ENGLAND, United Kingdom),we are an 24/7 crypto-currency trading platform that works automatically, and it has been registered in the UK company, we offer a no-experience trading method to help you remove unnecessary risks. Over the past five years, our experts have come up with a workable automated arbitrage trading software from manual strategic trading that can help you earn a lot of money. In 2020, we made a record of $1 million per day. From spot trading, futures trading and investment ICO project, we invested BTC, ETH and XRP heavily through our analysis and earned tens of millions of dollars.
</p>
</div>
</div>
<div class="wpb_text_column wpb_content_element">
<div class="wpb_wrapper">
<p style="text-align: justify;">
</p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid vc_row-o-content-middle vc_row-flex">
<div class="wpb_column vc_column_container vc_col-sm-12">
<div class="vc_column-inner">
<div class="wpb_wrapper"><div data-rstyle="height:|||90;" class="anps-empty-space"></div></div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid vc_column-gap-30">
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<h2 class="anps-heading" style="text-align: left;">
<span style="font-weight: 600;" data-rstyle="margin-bottom:|||20;font-size:|||30;line-height:|||1.3;" class="anps-heading__text">
Why We Exist?
Vision & Mission
</span>
</h2>
<div class="wpb_text_column wpb_content_element vc_custom_1524228952501">
<div class="wpb_wrapper">
<p style="text-align: left;">
We are uniting all key aspects of running an efficient cryptocurrency trading operation. From building highly efficient data centers to providing a streamlined mining system for our users.
Our mission and ultimate goal is to make cryptocurrency trading an easy, smart and profiting experience for all.
</p>
</div>
</div>
<div data-rstyle="height:|||30;" class="anps-empty-space"></div>
<div class="anps-btn-wrap anps-btn-wrap--left"><a data-rstyle="width:|||220;" href="index-2.html" class="anps-btn anps-btn--md anps-btn--style-0 anps-btn--gradient">Registration</a></div>
<div data-rstyle="height:|20||0;" class="anps-empty-space"></div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-3">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||15;font-size:|||;line-height:|||;" class="anps-heading__text"> Safe & Easy Investments </span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524574178434">
<div class="wpb_wrapper">
<p></p>
</div>
</div>
<div data-rstyle="height:|||35;" class="anps-empty-space"></div>
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||15;font-size:|||;line-height:|||;" class="anps-heading__text"> Crypto Opportunities </span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524574197946">
<div class="wpb_wrapper">
<p></p>
</div>
</div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-3">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||15;font-size:|||;line-height:|||;" class="anps-heading__text">24/7 Customer Support</span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524574187721">
<div class="wpb_wrapper">
<p></p>
</div>
</div>
<div data-rstyle="height:|||35;" class="anps-empty-space"></div>
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||15;font-size:|||;line-height:|||;" class="anps-heading__text">DDoS Protected System</span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524574202778">
<div class="wpb_wrapper">
<p></p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12">
<div class="vc_column-inner">
<div class="wpb_wrapper"><div data-rstyle="height:|30|40|60;" class="anps-empty-space"></div></div>
</div>
</div>
</div>
</div></div></div></div> </main>
<div style="background: #000537">
<div class="container content-container">
<div class="row">
<div class="col-md-12">
<div class="page-content-wrap">
<div class="vc_row wpb_row vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12 vc_col-md-offset-2 vc_col-md-8">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<br><br>
<h3 class="anps-heading" style="text-align: center;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||20;font-size:|||;line-height:|||;" class="anps-heading__text">Our advantages</span>
</h3>
<p class="anps-heading" style="text-align: center;">
<span style="font-weight: 300;" data-rstyle="margin-bottom:|||;font-size:|||20;line-height:|||;" class="anps-heading__text">
</span>
</p>
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12">
<div class="vc_column-inner">
<div class="wpb_wrapper"><div data-rstyle="height:|30|40|50;" class="anps-empty-space"></div></div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid vc_custom_1519980602043 vc_column-gap-30">
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<style>.vc_custom_1521193176589{background-color:#febd41!important;border-radius:100%!important}</style>
<div class="anps-icon anps-icon--left-content anps-icon--v-top">
<div class="anps-icon__col anps-icon__col--icon">
<div style="color: #000537;text-align: center; line-height: 40px;" data-rstyle="font-size:|||18;width:|||40;height:|||40;margin-right:|||25;margin-bottom:|||25;margin-left:|||0;" class="anps-icon__wrap vc_custom_1521193176589">
<i class="anps-icon__icon fa fa-check"></i>
</div>
</div>
<div class="anps-icon__col anps-icon__col--content">
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||10;font-size:|||;line-height:|||;" class="anps-heading__text">liquidity enhancements</span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524229105549">
<div class="wpb_wrapper">
<p style="text-align: left;"></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<style>.vc_custom_1521193217927{background-color:#febd41!important;border-radius:100%!important}</style>
<div class="anps-icon anps-icon--left-content anps-icon--v-top">
<div class="anps-icon__col anps-icon__col--icon">
<div style="color: #000537;text-align: center; line-height: 40px;" data-rstyle="font-size:|||18;width:|||40;height:|||40;margin-right:|||25;margin-bottom:|||25;margin-left:|||0;" class="anps-icon__wrap vc_custom_1521193217927">
<i class="anps-icon__icon fa fa-check"></i>
</div>
</div>
<div class="anps-icon__col anps-icon__col--content">
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||10;font-size:|||;line-height:|||;" class="anps-heading__text">privold fund objective and suitability</span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524229109164">
<div class="wpb_wrapper">
<p style="text-align: left;"></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12">
<div class="vc_column-inner">
<div class="wpb_wrapper"><div data-rstyle="height:|0||30;" class="anps-empty-space"></div></div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid vc_column-gap-30">
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<style>.vc_custom_1521193238557{background-color:#febd41!important;border-radius:100%!important}</style>
<div class="anps-icon anps-icon--left-content anps-icon--v-top">
<div class="anps-icon__col anps-icon__col--icon">
<div style="color: #000537;text-align: center; line-height: 40px;" data-rstyle="font-size:|||18;width:|||40;height:|||40;margin-right:|||25;margin-bottom:|||25;margin-left:|||0;" class="anps-icon__wrap vc_custom_1521193238557">
<i class="anps-icon__icon fa fa-check"></i>
</div>
</div>
<div class="anps-icon__col anps-icon__col--content">
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||10;font-size:|||;line-height:|||;" class="anps-heading__text">zero fees & diversification advantages</span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524229113579">
<div class="wpb_wrapper">
<p style="text-align: left;"></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<style>.vc_custom_1521193228634{background-color:#febd41!important;border-radius:100%!important}</style>
<div class="anps-icon anps-icon--left-content anps-icon--v-top">
<div class="anps-icon__col anps-icon__col--icon">
<div style="color: #000537;text-align: center; line-height: 40px;" data-rstyle="font-size:|||18;width:|||40;height:|||40;margin-right:|||25;margin-bottom:|||25;margin-left:|||0;" class="anps-icon__wrap vc_custom_1521193228634">
<i class="anps-icon__icon fa fa-check"></i>
</div>
</div>
<div class="anps-icon__col anps-icon__col--content">
<h4 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||10;font-size:|||;line-height:|||;" class="anps-heading__text">social and environmentally conscious product</span>
</h4>
<div class="wpb_text_column wpb_content_element vc_custom_1524229117445">
<div class="wpb_wrapper">
<p style="text-align: left;"></p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div></div></div></div>
</div>
<main class="site-main">
<div class="container content-container">
<div class="row">
<div class="col-md-12">
<div class="page-content-wrap">
<div class="vc_row wpb_row vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12">
<div class="vc_column-inner">
<div class="wpb_wrapper"><div data-rstyle="height:|0||60;" class="anps-empty-space"></div></div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid vc_column-gap-30 vc_row-o-content-middle vc_row-flex">
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<h5 class="anps-heading" style="text-align: left;">
<span style="color: #fff; font-weight: 600;" data-rstyle="margin-bottom:|||10;font-size:|||;line-height:|||;" class="anps-heading__text"></span>
</h5>
<h2 class="anps-heading" style="text-align: left;">
<span style="font-weight: 700;" data-rstyle="margin-bottom:|||20;font-size:34|28|36|;line-height:|||;" class="anps-heading__text">
About Instantfxoptiontrade LTD
</span>
</h2>
<div class="wpb_text_column wpb_content_element vc_custom_1524228490332">
<div class="wpb_wrapper">
<p style="text-align: justify">
Since Instantfxoptiontrade LTD has demonstrated outstanding performance and significantly expanded its assets in the previous period, the decision was made to start offering its investment products via specialized online services.
The Company is not a member, associate or subdivision of any other organization, so it is free to make totally independent decisions. Our team of full-time financial experts ensures effective and quick analysis of the current financial situation. Our mission is to provide every person the opportunity to gain maximal profit from investing at minimal risk.
</p>
</div>
</div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-6">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="anps-side-container">
<div class="anps-box">
<div class="anps-box__wrap">
<div class="wpb_single_image wpb_content_element vc_align_left">
<figure class="wpb_wrapper vc_figure">
<div class="vc_single_image-wrapper vc_box_border_grey">
<img width="1000" height="674" src="data/design/cryptonode/images/about2.jpg" class="vc_single_image-img attachment-full" alt=""/>
</div>
</figure>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div></div></div></div></main><footer class="site-footer"><div class="container"><div class="site-footer__main"><div class="row"><div class="site-footer__col site-footer__col--lg"><div id="anpsimages-2" class="widget widget_anpsimages"><img alt="CryptoNode" src="data/design/cryptonode/images/logo.png" style="width: 250px"/></div><div id="anpsspacings-4" class="widget widget_anpsspacings"><div class="empty-space block" style="height: 34px;"></div></div><div id="text-2" class="widget widget_text"><div class="textwidget"><p style="text-align: justify">When you need a wealth management company to handle your private investment matters, Instantfxoptiontrade is the leading overseas private investment corporation you can count on.</p></div></div></div><div class="site-footer__col"><div id="nav_menu-3" class="widget widget_nav_menu"><h3 class="widget-title">Instantfxoptiontrade</h3><div class="menu-services-container"><ul id="menu-services" class="menu"><li id="menu-item-925" class="menu-item menu-item-type-post_type menu-item-object-portfolio menu-item-925"><a href="index.html">Home</a></li><li id="menu-item-926" class="menu-item menu-item-type-post_type menu-item-object-portfolio menu-item-926"><a href="about.php">About us</a></li><li id="menu-item-927" class="menu-item menu-item-type-post_type menu-item-object-portfolio menu-item-927"><a href="faq.php">FAQ</a></li></ul></div></div></div><div class="site-footer__col"><div id="nav_menu-4" class="widget widget_nav_menu"><h3 class="widget-title">Terms of Use</h3><div class="menu-terms-of-use-container"><ul id="menu-terms-of-use" class="menu"><li id="menu-item-949" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-949"><a href="rules.php">Terms and Conditions</a></li><li id="menu-item-950" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-950"><a href="rules.php">Copyright</a></li></ul></div></div></div><div class="site-footer__col"><div id="text-6" class="widget widget_text"><h3 class="widget-title">Contact</h3><div class="textwidget"><p>info@Instantfxoptiontrade.com<br/><br/>10 111 Mallinson Road London, SW11 1BL, ENGLAND, United Kingdom</p></div></div></div></div></div></div><div class="copyright-footer"><div class="container"><div class="copyright-footer__row"><div class="copyright-footer__col"><div id="text-3" class="widget widget_text"><div class="textwidget"><p>Copyright © 2021 advancedbitcoinminer LTD. All rights reserved.</p></div></div></div><div class="copyright-footer__col copyright-footer__col--right"><div id="nav_menu-5" class="widget widget_nav_menu"><div class="menu-social-links-container"><ul id="menu-social-links" class="menu"><li id="menu-item-1057" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1057"><a href="#"></a></li><li id="menu-item-1058" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1058"><a href="#">Telegram</a></li><li id="menu-item-1059" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1059"><a href="#"></a></li></ul></div></div></div></div></div></div></footer></div></div><script type="text/javascript" src="data/design/cryptonode/js/modernizr.js"></script><script type="text/javascript" src="data/design/cryptonode/js/pikaday.js"></script><script type="text/javascript" src="data/design/cryptonode/js/jquery.swipebox.js"></script><script type="text/javascript" src="data/design/cryptonode/js/bootstrap/bootstrap.min.js"></script><script type="text/javascript" src="data/design/cryptonode/js/jquery.countdown.min.js"></script><script type="text/javascript" src="data/design/cryptonode/js/doubletaptogo.js"></script><script type="text/javascript" src="data/design/cryptonode/js/flexibility.js"></script>
<script type="text/javascript">var anps={crypto_values:"",};</script>
<script type="text/javascript" src="data/design/cryptonode/js/functions.js"></script><script type="text/javascript" src="data/design/cryptonode/js/owlcarousel/owl.carousel.js"></script><script type="text/javascript" src="data/plugins/js_composer/assets/js/dist/js_composer_front.min.js"></script></body>
<!-- Mirrored from cryptonode.ltd/?a=cust&page=about by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Jul 2020 11:50:16 GMT -->
</html><script data-pagespeed-no-defer>(function(){function f(b){var a=window;if(a.addEventListener)a.addEventListener("load",b,!1);else if(a.attachEvent)a.attachEvent("onload",b);else{var c=a.onload;a.onload=function(){b.call(this);c&&c.call(this)}}};window.pagespeed=window.pagespeed||{};var k=window.pagespeed;function l(b,a,c,g,h){this.h=b;this.i=a;this.l=c;this.j=g;this.b=h;this.c=[];this.a=0}l.prototype.f=function(b){for(var a=0;250>a&&this.a<this.b.length;++a,++this.a)try{document.querySelector(this.b[this.a])&&this.c.push(this.b[this.a])}catch(c){}this.a<this.b.length?window.setTimeout(this.f.bind(this),0,b):b()};k.g=function(b,a,c,g,h){if(document.querySelector&&Function.prototype.bind){var d=new l(b,a,c,g,h);f(function(){window.setTimeout(function(){d.f(function(){for(var a="oh="+d.l+"&n="+d.j,a=a+"&cs=",b=0;b<d.c.length;++b){var c=0<b?",":"",c=c+encodeURIComponent(d.c[b]);if(131072<a.length+c.length)break;a+=c}k.criticalCssBeaconData=a;var b=d.h,c=d.i,e;if(window.XMLHttpRequest)e=new XMLHttpRequest;else if(window.ActiveXObject)try{e=new ActiveXObject("Msxml2.XMLHTTP")}catch(m){try{e=new ActiveXObject("Microsoft.XMLHTTP")}catch(n){}}e&&(e.open("POST.html",b+(-1==b.indexOf("?")?"?":"&")+"url="+encodeURIComponent(c)),e.setRequestHeader("Content-Type","application/x-www-form-urlencoded"),e.send(a))})},0)})}};k.criticalCssBeaconInit=k.g;})();pagespeed.selectors=["#lang_sel a.lang_sel_sel","*",".accb1",".accb1 img",".alert",".anps-btn--style-0",".anps-btn--style-1",".anps-btn--style-2",".anps-btn--style-3",".anps-btn--style-8",".anps-btn--style-9",".anps-member__name",".anps-member__title",".anps_menu_widget .menu a",".botwelcome",".boxed .site",".boxed .site-footer",".breadcrumb",".breadcrumb a",".breadcrumb li",".btn.btn-lg",".btn.btn-wide",".btn.btn-xs",".cart_totals .order-total",".cart_totals th",".comment-author",".comment-edit-link",".comment-meta__author",".comment-reply-link",".contact-form .form-group .wpcf7-not-valid-tip",".contact-form .form-group label",".container",".copyright-footer",".copyright-footer a",".dropcap",".featured-has-icon .featured-title i",".featured-title",".h1",".h2",".h3",".h4",".h5",".headcoins",".header-wrap",".heading-subtitle",".info-table-content",".info-table-content strong",".inpts",".intanimation",".js-is-sticky .header-wrap",".large-above-menu.style-2 .widget_anpstext",".megamenu-title",".menu-button",".mini-cart-content",".mini-cart-content .buttons a",".mini-cart-content .total",".mini-cart-list .empty",".mini-cart-list .remove",".mini_cart_item_title",".orderform .minus",".orderform .plus",".owl-nav button",".page-header .page-title",".post-author-title strong",".post-author__title strong",".post-info th",".post-tags a",".post-tags__title",".post__title",".price del",".product-top-meta .price",".product_list_widget del",".product_list_widget del .amount",".product_meta",".product_meta .posted_in a",".product_meta > span > span",".projects-item .project-title",".quantity .minus",".quantity .plus",".regular-radio",".regular-radio + label",".sbmt",".scrollup a",".search-notice-field",".search-result-title",".select2-container .select2-choice",".select2-container .select2-choice > .select2-chosen",".select2-results li",".sidebar .download a",".sidebar .working-hours td",".sidebar a",".single .page-header .page-title",".site-footer",".site-footer .download i",".site-footer .download-icon",".site-footer .mini-cart-list + p.total > strong",".site-footer .searchform #searchsubmit",".site-footer .searchform input[type=\"text\"]",".site-footer .widget_calendar table",".site-footer .widget_calendar table td",".site-footer .widget_calendar table th",".site-footer .widget_calendar th",".site-footer .widget_pages a",".site-footer .widget_price_filter .price_slider_amount button.button",".site-footer .widget_shopping_cart_content .buttons a",".site-footer .woocommerce-product-search input.search-field",".site-footer .woocommerce-product-search input[type=\"submit\"]",".site-main .social.social-minimal a",".site-main .wp-caption p.wp-caption-text",".site-navigation .main-menu li a",".social.social-border a",".social.social-transparent-border a",".title.h5",".top-bar .social a",".top-bar-style-2",".topwelcome",".vc_custom_1520428420584",".vc_custom_1521193176589",".vc_custom_1521193217927",".vc_custom_1521193228634",".vc_custom_1521193238557",".vc_custom_1530870010686",".vc_custom_1530870910338",".vc_custom_1531221934871",".vc_custom_1531221976897",".vc_custom_1531222660319",".vc_custom_1531222664629",".vc_custom_1531222668957",".vc_custom_1531313736666",".vc_custom_1531313739378",".vc_custom_1531313742873",".vc_custom_1531313745825",".vc_custom_1531313781657",".vc_custom_1531313816626",".vc_custom_1531314698111",".vc_custom_1531314757865",".vc_custom_1531314782893",".vc_custom_1531316559867",".vc_custom_1531317468795",".vc_custom_1531741378678",".vc_custom_1536314096772",".vc_custom_1536314305860",".vc_custom_1536314420423",".vc_custom_1536316584046",".vc_custom_1536316591546",".vc_custom_1536316594980",".vc_custom_1536317059066",".vc_custom_1536317062892",".vc_custom_1536317066594",".vc_gitem_row .vc_gitem-col.anps-grid .post-desc",".vc_gitem_row .vc_gitem-col.anps-grid-mansonry .post-desc",".vc_separator.vc_sep_color_grey .vc_sep_line",".widget_calendar a",".widget_rss .widget-title",".widget_rss ul .rss-date",".widget_rss ul cite",".woocommerce form label",".woocommerce-product-gallery__trigger",".wpcf7 .form-group .wpcf7-not-valid-tip",".wpcf7 .form-group label","[itemprop=\"author\"]","a","a.featured-lightbox-link svg","aside .mini-cart-list + p.total > strong","aside .widget_shopping_cart_content .buttons a","body","div.wpcf7-mail-sent-ng","div.wpcf7-validation-errors","em","h1","h2","h3","h4","h5","h6","html","input","nav.site-navigation","nav.site-navigation .current-menu-item > a","nav.site-navigation ul li a","ol.list span","select","ss .logo .logo-wrap","ss .vc_custom_1530865712720","table.table > tbody th","table.table > tfoot th","table.table > thead th","td.inheader","td.item","textarea"];pagespeed.criticalCssBeaconInit('/ngx_pagespeed_beacon','index3898.html?a=cust&amp;page=about','fffI38n8Hs','2e0Comppa4g',pagespeed.selectors);</script><noscript class="psa_add_styles"><link rel="stylesheet" href="data/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css" type="text/css" media="all"/><link rel="stylesheet" href="data/design/cryptonode/css/bootstrap.css" type="text/css" media="all"/><link rel="stylesheet" href="data/design/cryptonode/css/core.css" type="text/css" media="all"/><link rel="stylesheet" href="data/design/cryptonode/css/components.html" type="text/css" media="all"/><link rel="stylesheet" href="data/design/cryptonode/css/button.css" type="text/css" media="all"/><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans%3A400italic%2C400%2C500%2C600%2C700%2C300&amp;subset=latin%2Clatin-ext&amp;ver=4.9.14" type="text/css" media="all"/><style type="text/css">ss .logo .logo-wrap{font-family:Arial,Helvetica,sans-serif}.btn,.button,.cart_totals th,.contact-number,.featured-title,.filter-dark button,.filter:not(.filter-dark) button,.font1,.h5,.onsale,.orderform .quantity-field,.page-header .page-title,.product-top-meta,.quantity .quantity-field,.rev_slider,.search-notice-label,.site-footer .widget_recent_entries a,.title.h5,:not(.widget)>.download,h1,h2,h3,h4,h5,h6,table.table>tbody th,table.table>tfoot th,table.table>thead th{font-family:"Nunito Sans"}.breadcrumb{font-family:"Nunito Sans"}.alert,.btn.btn-xs,.contact-form .form-group .wpcf7-not-valid-tip,.contact-form .form-group label,.heading-subtitle,.large-above-menu.style-2 .widget_anpstext,.search-result-title,.top-bar-style-2,.wpcf7 .form-group .wpcf7-not-valid-tip,.wpcf7 .form-group label,body,div.wpcf7-mail-sent-ng,div.wpcf7-validation-errors{font-family:"Nunito Sans"}.megamenu-title,.menu-button,nav.site-navigation ul li a{font-family:"Nunito Sans"}@media (max-width:1199px){.site-navigation .main-menu li a{font-family:"Nunito Sans"}}.alert,.anps_menu_widget .menu a:before,.breadcrumb li:before,.btn.btn-lg,.btn.btn-wide,.product_meta,.projects-item .project-title,.site-main .wp-caption p.wp-caption-text,.vc_gitem_row .vc_gitem-col.anps-grid .post-desc,.vc_gitem_row .vc_gitem-col.anps-grid-mansonry .post-desc,body{font-size:18px}.h1,h1{font-size:31px}.h2,h2{font-size:45px}.h3,h3{font-size:32px}.h4,h4{font-size:22px}.h5,h5{font-size:20px}nav.site-navigation,nav.site-navigation ul li a{font-size:16px}.site-footer{font-size:18px}.copyright-footer{font-size:16px}@media (min-width:1000px){.page-header .page-title{font-size:36px}.single .page-header .page-title{font-size:36px}}@media (min-width:1400px){.boxed .site,.boxed .site-footer,.container{width:1370px}}html{--anps-text-color:#fff;--anps-page-bg:#0a1992;--anps-secondary:#ffece6;--anps-primary:#fcc754;--anps-headings:#fcc754;--anps-menu-font-size:16px;--anps-submenu-font-size:15px;--anps-top-bar-font-size:13px;--anps-breadcrumbs-color:#999cab;--anps-breadcrumbs-border-color:#e7e7e7;--anps-breadcrumbs-bg-color:#fff;--anps-main-space-top:90px;--anps-main-space-bottom:90px;--anps-top-bar-color:#fdfdfd;--anps-top-bar-bg-color:#000537;--anps-top-bar-height:42px;--anps-menu-mobile-icons:#fff;--anps-submenu-bg-color:#fff;--anps-submenu-color:#8c8c8c;--anps-submenu-color--active:#000;--anps-submenu-color--hover:#000;--anps-page-title:#fff;--anps-page-header-bg:linear-gradient(90deg,#182373,#4f2fac);--anps-page-header-height:280px;--anps-page-header-lg-height:370px;--anps-menu-color:#fdfdfd;--anps-menu-color--hover:#fdc962;--anps-menu-color--active:#fff;--anps-header-search-text-color:#000;--anps-header-search-background-color:#888;--anps-hmain-bg:#171d2f;--anps-hbar-height:110px;--anps-hbar-height--sticky:90px;--anps-hbar-m-height:74px;--anps-hbar-m-height--sticky:60px;--anps-sticky-bg:#000537;--anps-sticky-color:#fff;--anps-sticky-color--hover:#fff;--anps-sticky-color--active:#fff;--anps-crypto-bar-bg:#000;--anps-footer-heading-color:#fcc754;--anps-menu-spacing:15px;--anps-whitelist-token-overlay-bg-color:rgba(255,255,255,.8)}#lang_sel a.lang_sel_sel,.anps-member__title,.comment-edit-link,.comment-edit-link::before,.comment-reply-link,.info-table-content strong,.mini-cart-content,.mini-cart-list .empty,.post-tags a,.price del,.product_list_widget del,.product_list_widget del .amount,.product_meta .posted_in a,.product_meta>span>span,.search-notice-field,.select2-container .select2-choice,.select2-container .select2-choice>.select2-chosen,.select2-results li,.sidebar a,.site-footer .download-icon,.site-main .social.social-minimal a:focus,.site-main .social.social-minimal a:hover,.social.social-border a,.social.social-transparent-border a,.top-bar .social a,.widget_rss .widget-title:focus,.widget_rss .widget-title:hover,body,ol.list span{color:#fdfdfd}.anps-member-social__link,.bg-primary,.demo_store_wrapper,.featured-has-icon .featured-title:before,.mini-cart-content .buttons a,.nav-links>:not(.dots).current,.nav-links>:not(.dots):focus,.nav-links>:not(.dots):hover,.onsale,.owl-nav button,.pika-next,.pika-prev,.sidebar .download a,.site-footer .widget_price_filter .price_slider_amount button.button,.site-footer .widget_price_filter .ui-slider .ui-slider-range,.site-footer .widget_shopping_cart_content .buttons a,.social a,.widget_calendar a,.widget_calendar caption,.woocommerce-product-gallery__trigger,article.post.sticky .post-content:before,article.post.sticky .post-meta:before,article.post.sticky .post-title:before,aside .widget_price_filter .price_slider_amount button.button,aside .widget_price_filter .ui-slider .ui-slider-range,aside .widget_shopping_cart_content .buttons a,mark,table.table>tbody tr.bg-primary,table.table>tbody.bg-primary tr,table.table>tfoot tr.bg-primary,table.table>tfoot.bg-primary tr,table.table>thead tr.bg-primary,table.table>thead.bg-primary tr,ul.page-numbers>li>.current,ul.page-numbers>li>:focus,ul.page-numbers>li>:hover{background-color:#fcc754}::-moz-selection{background-color:#fcc754}::selection{background-color:#fcc754}.anps-info-icons-wrap,.anps-info-it-wrap,.breadcrumb a:focus,.breadcrumb a:hover,.comment-date i,.contact-info i,.copyright-footer a,.counter-wrap .title,.featured-has-icon.simple-style .featured-title i,.filter-dark button.selected,.filter:not(.filter-dark) button.selected,.filter:not(.filter-dark) button:focus,.heading-left span:before,.heading-middle span:before,.icon-media,.info-table-icon,.jobtitle,.list li:before,.megamenu-title,.mini-cart-content .total .amount,.panel-heading a.collapsed:focus,.panel-heading a.collapsed:hover,.post-info td a:focus,.post-info td a:hover,.post-meta i,.product_list_widget .amount,.product_list_widget ins,.product_meta .posted_in a:focus,.product_meta .posted_in a:hover,.projects-item .project-title,.site-footer .download a:focus,.site-footer .download a:hover,.site-footer .social.social-minimal a:focus,.site-footer .social.social-minimal a:hover,.site-footer .widget_price_filter .price_slider_amount .from,.site-footer .widget_price_filter .price_slider_amount .to,.site-footer .widget_recent_entries .post-date:before,.social.social-border a:focus,.social.social-border a:hover,.social.social-transparent-border a:focus,.social.social-transparent-border a:hover,.star-rating,.stars,.stars a:focus,.stars a:hover,.testimonials-style-3 .testimonials-wrap .content p::before,.testimonials-style-3 .testimonials-wrap .name-user,.vc_gitem_row .vc_gitem-col.anps-grid .vc_gitem-post-data-source-post_date>div:before,.vc_gitem_row .vc_gitem-col.anps-grid-mansonry .vc_gitem-post-data-source-post_date>div:before,.widget_calendar #today,.widget_rss ul .rsswidget,.wpcf7-form-control-wrap[class*=date-]:after,[itemprop=datePublished]:before,a,a.featured-lightbox-link,aside .widget_price_filter .price_slider_amount .from,aside .widget_price_filter .price_slider_amount .to,aside.sidebar .widget_nav_menu .current-menu-item>a,b,header a:focus,nav.site-navigation ul li a:active,nav.site-navigation ul li a:focus,nav.site-navigation ul li a:hover,ol.list,ul.testimonial-wrap .rating,ul.testimonial-wrap .user-data .name-user{color:#fcc754}@media (min-width:768px){.featured-has-icon:focus .featured-title i,.featured-has-icon:hover .featured-title i{color:#fcc754}}a.featured-lightbox-link svg{fill:#fcc754}nav.site-navigation .current-menu-item>a{color:#fcc754!important}.blockquote-style-1 p,.blockquote-style-2 p,.featured-content,.gallery-fs .owl-item a.selected:after,.gallery-fs .owl-item a:focus:after,.gallery-fs .owl-item a:hover:after,.post-minimal-wrap,blockquote:not([class]) p{border-color:#fcc754}.mini-cart-content .buttons a:focus,.mini-cart-content .buttons a:hover,.owl-nav button:focus,.owl-nav button:hover,.sidebar .download a:focus,.sidebar .download a:hover,.site-footer .widget_price_filter .price_slider_amount button.button:focus,.site-footer .widget_price_filter .price_slider_amount button.button:hover,.site-footer .widget_shopping_cart_content .buttons a:focus,.site-footer .widget_shopping_cart_content .buttons a:hover,.widget_calendar a:focus,.widget_calendar a:hover,.woocommerce-product-gallery__trigger:focus,.woocommerce-product-gallery__trigger:hover,aside .widget_shopping_cart_content .buttons a:focus,aside .widget_shopping_cart_content .buttons a:hover{background-color:#1d2128}.copyright-footer a:focus,.copyright-footer a:hover,.sidebar a:focus,.sidebar a:hover,a:focus,a:hover{color:#fff}.form-group input:not([type=submit]):focus,.form-group input:not([type=submit]):hover,.form-group textarea:focus,.form-group textarea:hover,.input-text:focus,.input-text:hover,.wpcf7 input:not([type=submit]):focus,.wpcf7 input:not([type=submit]):hover,.wpcf7 textarea:focus,.wpcf7 textarea:hover,input{outline-color:#1d2128}.scrollup a:hover{border-color:#1d2128}.anps-member__name,.breadcrumb a,.cart_totals .order-total,.cart_totals th,.comment-author,.comment-meta__author,.dropcap,.featured-title,.h5,.info-table-content,.mini-cart-content .total,.mini-cart-list .remove,.orderform .minus:focus,.orderform .minus:hover,.orderform .plus:focus,.orderform .plus:hover,.post-author-title strong,.post-author__title strong,.post-info th,.post-tags__title,.post__title,.product-top-meta .price,.quantity .minus:focus,.quantity .minus:hover,.quantity .plus:focus,.quantity .plus:hover,.sidebar .working-hours td,.site-footer .mini-cart-list+p.total>strong,.site-main .social.social-minimal a,.title.h5,.widget_rss ul .rss-date,.widget_rss ul cite,.woocommerce form label,[itemprop="author"],aside .mini-cart-list+p.total>strong,em,h1,h2,h3,h4,h5,h6,table.table>tbody th,table.table>tfoot th,table.table>thead th{color:#fcc754}.mini_cart_item_title{color:#fcc754!important}.site-footer{background-color:#000537}.site-footer{color:#cacbd1}.site-footer .searchform #searchsubmit,.site-footer .searchform input[type="text"],.site-footer .widget_calendar table,.site-footer .widget_calendar table td,.site-footer .widget_calendar table th,.site-footer .woocommerce-product-search input.search-field,.site-footer .woocommerce-product-search input[type="submit"]{border-color:#2e2e2e}.site-footer .download i:after,.site-footer .widget_calendar th:after,.site-footer .widget_pages a:after{background-color:#2e2e2e}.copyright-footer{background-color:#010745;color:#fff}.anps-btn--style-0{color:#020e68;border-radius:10px;background-image:linear-gradient(to right,#fdcb68,orange);box-shadow:0 10px 25px 0 #061487}.anps-btn--style-1{background-color:#fdcb68;border-radius:5px;color:#000}.anps-btn--style-2{color:#fcc754;border-color:#ffb531;border-radius:10px;border-width:2px}.anps-btn--style-3{color:#ffb531}.anps-btn--style-8,.sbmt{color:#020e68;background-image:linear-gradient(to right,#fdcb68,orange);border-color:#ffb531;border-radius:30px;border-width:2px;border:0;padding:10px 40px}.anps-btn--style-9{color:#fff;border-color:#ffb531;border-radius:5px;border-width:2px}.anps-btn--style-0:focus,.anps-btn--style-0:hover{color:#020e68;border-radius:10px;box-shadow:0 10px 35px 0 #020e68}.anps-btn--style-1:focus,.anps-btn--style-1:hover{background-color:#ffd98e;border-radius:5px;color:#000}.anps-btn--style-2:focus,.anps-btn--style-2:hover{color:#ffb531;border-color:#ffb531;border-radius:10px;border-width:2px;background:#ffb531;color:#000}.anps-btn--style-3:focus,.anps-btn--style-3:hover{color:#f5473b}.anps-btn--style-8:focus,.anps-btn--style-8:hover,.sbmt:focus,.sbmt:hover{color:#000;background-image:linear-gradient(to right,orange,#fdcb68);border-color:#fdcb68;border-radius:30px;border-width:2px}.anps-btn--style-9:focus,.anps-btn--style-9:hover{color:#ffb531;border-color:#ffb531;border-radius:5px;border-width:2px}.header-wrap{height:74px}.js-is-sticky .header-wrap{height:60px}@media (min-width:1200px){.header-wrap{height:90px}.js-is-sticky .header-wrap{height:90px}}.inpts{color:#000;font-size:16px;padding:7px 15px;border:1px solid #ccc;margin:3px;width:100%}*,::before,:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;margin:0}:active,:focus,:hover{outline:0;outline-offset:0}input:-webkit-autofill,input:-webkit-autofill:focus,input:-webkit-autofill:hover,select:-webkit-autofill,select:-webkit-autofill:focus,select:-webkit-autofill:hover,textarea:-webkit-autofill,textarea:-webkit-autofill:focus,textarea:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 1000px transparent inset;transition:background-color 5000s ease-in-out 0s;-webkit-text-fill-color:#000!important}*{-webkit-touch-callout:text!important;-webkit-user-select:text!important;-khtml-user-select:text!important;-moz-user-select:text!important;-ms-user-select:text!important;user-select:text!important}@media (max-width:1000px){.topwelcome{margin-top:130px}.botwelcome{margin-top:50px}}</style><link rel="stylesheet" href="data/plugins/js_composer/assets/css/js_composer.min.css" type="text/css" media="all"/><style type="text/css" data-type="vc_shortcodes-custom-css">ss .vc_custom_1530865712720{margin-bottom:10px!important}.headcoins{background:url(data/design/cryptonode/images/coins.png) right no-repeat;animation:animatednumbers 15s linear infinite;-moz-animation:animatednumbers 15s linear infinite;-webkit-animation:animatednumbers 15s linear infinite;-o-animation:animatednumbers 15s linear infinite}@keyframes animatednumbers{0{background-position:100% 0}25%{background-position:90% 100%}50%{background-position:100% 0}75%{background-position:90% 100%}}.vc_custom_1531741378678{background:url(data/design/cryptonode/images/statbg.jpg) repeat-x 0 100% #000433;animation:graph 60s linear infinite;-webkit-animation:graph 60s linear infinite}@keyframes graph{from{background-position:-2000px 100%,0 0}to{background-position:0 100%,0 0}}@-webkit-keyframes graph{from{background-position:-2000px 100%,0 0}to{background-position:0 100%,0 0}}@keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}@-moz-keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}@-webkit-keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}@-o-keyframes intanimatedBackground1{0{background-position:0 0}100%{background-position:-854px 854px}}.intanimation{background-image:url(data/design/cryptonode/images/header-lines.png);animation:intanimatedBackground1 10s linear infinite;-moz-animation:intanimatedBackground1 10s linear infinite;-webkit-animation:intanimatedBackground1 10s linear infinite;-o-animation:intanimatedBackground1 10s linear infinite}.vc_custom_1530870910338{margin-right:0!important;margin-left:0!important;border-top-width:1px!important;border-right-width:1px!important;border-bottom-width:1px!important;border-left-width:1px!important;border-left-color:#eee!important;border-left-style:solid!important;border-right-color:#eee!important;border-right-style:solid!important;border-top-color:#0a1992!important;border-top-style:solid!important;border-bottom-color:#eee!important;border-bottom-style:solid!important}.vc_custom_1531221976897{background:url(data/design/cryptonode/images/plansbg.jpg) top center!important;background-repeat:no-repeat!important}.vc_custom_1531313736666{background-color:#000537!important}.vc_custom_1531313742873{background-color:#000537!important}.vc_custom_1531313781657{margin-bottom:25px!important}.vc_custom_1531316559867{margin-bottom:25px!important}.vc_custom_1531313739378{background-color:#000537!important}.vc_custom_1531313745825{background-color:#000537!important}.vc_custom_1531317468795{margin-bottom:25px!important}.vc_custom_1531313816626{margin-bottom:25px!important}.vc_custom_1531314757865{border-radius:100%!important}.vc_custom_1531314782893{border-radius:100%!important}.vc_custom_1536314096772{border-radius:100%!important}.vc_custom_1531314698111{border-radius:100%!important}.vc_custom_1536314420423{border-radius:100%!important}.vc_custom_1536314305860{border-radius:100%!important}.vc_custom_1530870010686{border-right-width:1px!important;border-left-width:1px!important;border-left-color:#eee!important;border-left-style:solid!important;border-right-color:#eee!important;border-right-style:solid!important}.vc_custom_1536316584046{margin-bottom:10px!important}.vc_custom_1536316591546{margin-bottom:10px!important}.vc_custom_1536316594980{margin-bottom:10px!important}.vc_custom_1531221934871{background-position:center!important;background-repeat:no-repeat!important;background-size:cover!important}.vc_custom_1531313736666,.vc_custom_1531313739378,.vc_custom_1531313742873,.vc_custom_1531313745825{background-color:#000537!important;-webkit-transition:all .3s ease-in-out;-moz-transition:all .3s ease-in-out;-o-transition:all .3s ease-in-out;-ms-transition:all .3s ease-in-out;transition:all .3s ease-in-out}.vc_custom_1531313736666:hover,.vc_custom_1531313739378:hover,.vc_custom_1531313742873:hover,.vc_custom_1531313745825:hover{background-color:#060d53!important}.vc_custom_1531222660319{padding-top:10px!important;padding-right:50px!important;padding-bottom:45px!important;padding-left:50px!important;background-color:#ffa500!important;-webkit-transition:all .3s ease-in-out;-moz-transition:all .3s ease-in-out;-o-transition:all .3s ease-in-out;-ms-transition:all .3s ease-in-out;transition:all .3s ease-in-out;border-radius:20px}.vc_custom_1531222660319:hover{padding-top:20px!important;padding-right:50px!important;padding-bottom:55px!important;padding-left:50px!important;background-color:#fdca67!important}.vc_custom_1531222664629{padding-top:50px!important;padding-right:50px!important;padding-bottom:45px!important;padding-left:50px!important;background-color:#ffa500!important}.vc_custom_1531222668957{padding-top:50px!important;padding-right:50px!important;padding-bottom:45px!important;padding-left:50px!important;background-color:#ffa500!important}.vc_custom_1536317059066{margin-bottom:20px!important}.vc_custom_1536317062892{margin-bottom:20px!important}.vc_custom_1536317066594{margin-bottom:20px!important}.vc_separator.vc_sep_color_grey .vc_sep_line{border-color:#000537}.regular-radio{display:none}.regular-radio+label{-webkit-appearance:none;background-color:#e1e1e1;border:2px solid #e1e1e1;border-radius:20px;width:100%;display:inline-block;position:relative;color:#000;padding:4px 15px}.regular-radio:checked+label{background:#feb224;border:2px solid #feb224}td.inheader{font-weight:700;text-align:left;color:#fff;padding:10px 20px;background:#000537;padding-left:30px;font-size:16px;border-radius:20px}td.item{background-color:none;color:#fff;padding:7px;border:0;text-align:left;font-size:14px;padding-left:30px;border-radius:20px}.accb1{min-width:130px;width:11.6%;height:100px;background:#000537;border-radius:10px 10px 10px 10px;-moz-border-radius:10px 10px 10px 10px;-webkit-border-radius:10px 10px 10px 10px;float:left;text-align:center;color:#fff;font-size:14px;margin:0 5px 20px 5px;-webkit-transition:.3s ease-in-out;-moz-transition:.3s ease-in-out;-ms-transition:.3s ease-in-out;-o-transition:.3s ease-in-out;transition:.3s ease-in-out;-webkit-box-shadow:0 7px 15px -9px rgba(0,0,0,.3);-moz-box-shadow:0 7px 15px -9px rgba(0,0,0,.3);box-shadow:0 7px 15px -9px rgba(0,0,0,.3)}.accb1:hover{background:#ffa501;color:#fff}.accb1 img{display:block;padding:15px 0 5px 0;width:45px}</style><style>.vc_custom_1520428420584{padding-top:5px!important;padding-right:25px!important;padding-bottom:5px!important;padding-left:25px!important;background-color:#ffece6!important;border-radius:5px!important}</style><style>.vc_custom_1521193176589{background-color:#febd41!important;border-radius:100%!important}</style><style>.vc_custom_1521193217927{background-color:#febd41!important;border-radius:100%!important}</style><style>.vc_custom_1521193238557{background-color:#febd41!important;border-radius:100%!important}</style><style>.vc_custom_1521193228634{background-color:#febd41!important;border-radius:100%!important}</style></noscript><script data-pagespeed-no-defer>(function(){function b(){var a=window,c=e;if(a.addEventListener)a.addEventListener("load",c,!1);else if(a.attachEvent)a.attachEvent("onload",c);else{var d=a.onload;a.onload=function(){c.call(this);d&&d.call(this)}}};var f=!1;function e(){if(!f){f=!0;for(var a=document.getElementsByClassName("psa_add_styles"),c=0,d;d=a[c];++c)if("NOSCRIPT"==d.nodeName){var k=document.createElement("div");k.innerHTML=d.textContent;document.body.appendChild(k)}}}function g(){var a=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame||null;a?a(function(){window.setTimeout(e,0)}):b()}
var h=["pagespeed","CriticalCssLoader","Run"],l=this;h[0]in l||!l.execScript||l.execScript("var "+h[0]);for(var m;h.length&&(m=h.shift());)h.length||void 0===g?l[m]?l=l[m]:l=l[m]={}:l[m]=g;})();
pagespeed.CriticalCssLoader.Run();</script>